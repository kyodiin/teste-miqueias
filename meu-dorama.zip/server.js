require("dotenv").config();
const express = require("express");
const cors    = require("cors");
const crypto  = require("crypto");
const path    = require("path");

function gerarTxId() {
  return crypto.randomBytes(8).toString("hex");
}

const app = express();
app.use(cors());
app.use("/webhook", express.raw({ type: "application/json" }));
app.use(express.json());

// ─── Serve tudo de public/ ────────────────────────────────────────────────────
// public/index.html    = quiz (gerado por npm run build no projeto pai)
// public/pagar.html    = checkout PIX
// public/obrigado.html = página pós-pagamento
app.use(express.static(path.join(__dirname, "public")));

// ─── Abacate Pay ──────────────────────────────────────────────────────────────
const ABACATE_API = "https://api.abacatepay.com/v1";
const abacateHeaders = () => ({
  "Content-Type":  "application/json",
  "Authorization": `Bearer ${process.env.ABACATEPAY_API_KEY}`,
});

// ─── Planos do dorama ─────────────────────────────────────────────────────────
const PLANOS = {
  conto:   { nome: "Meu Dorama — Conto",            preco: 19.90, paginas: "~30 páginas" },
  novela:  { nome: "Meu Dorama — Novela",           preco: 29.90, paginas: "~50 páginas" },
  romance: { nome: "Meu Dorama — Romance Completo", preco: 39.90, paginas: "~70 páginas" },
};

// ─── Helpers ──────────────────────────────────────────────────────────────────
function sha256(str) {
  return crypto.createHash("sha256").update((str || "").toLowerCase().trim()).digest("hex");
}

// ─── CAPI Meta ────────────────────────────────────────────────────────────────
async function dispararCAPI({ email, nome, valor, eventId }) {
  const pixelId = process.env.META_PIXEL_ID;
  const token   = process.env.META_CAPI_TOKEN;
  if (!pixelId || !token) return;

  const userData = { em: [sha256(email)] };
  if (nome) {
    const partes = nome.split(" ");
    userData.fn = [sha256(partes[0])];
    if (partes.length > 1) userData.ln = [sha256(partes.slice(1).join(" "))];
  }

  const payload = {
    data: [{
      event_name:       "Purchase",
      event_time:       Math.floor(Date.now() / 1000),
      event_id:         eventId,
      action_source:    "website",
      event_source_url: process.env.BASE_URL || "",
      user_data:        userData,
      custom_data:      { value: valor, currency: "BRL" },
    }],
  };
  if (process.env.META_TEST_CODE) payload.test_event_code = process.env.META_TEST_CODE;

  try {
    const r = await fetch(
      `https://graph.facebook.com/v19.0/${pixelId}/events?access_token=${token}`,
      { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) }
    );
    const d = await r.json();
    if (d.error) console.error("❌ CAPI erro:", d.error.message);
    else console.log(`📡 CAPI Purchase | event_id: ${eventId}`);
  } catch(e) { console.error("❌ CAPI fetch erro:", e.message); }
}

// ─── UTMify ───────────────────────────────────────────────────────────────────
async function dispararUTMify({ pagamentoId, email, nomeCliente, telefone, valor, itens, utms, metodo }) {
  const token = process.env.UTMIFY_TOKEN;
  if (!token) return;

  const agora = new Date().toISOString().replace("T", " ").slice(0, 19);
  const body  = {
    isTest:        false,
    orderId:       String(pagamentoId),
    platform:      "other",
    paymentMethod: "pix",
    status:        "paid",
    createdAt:     agora,
    approvedDate:  agora,
    refundedAt:    null,
    customer: { name: nomeCliente || email.split("@")[0], email, phone: telefone || null, country: "BR", document: null },
    products: (itens || []).map(i => ({
      id:           String(i.id),
      name:         i.titulo,
      planId:       null,
      planName:     null,
      quantity:     1,
      priceInCents: Math.round(i.preco * 100),
    })),
    trackingParameters: {
      utm_source:   utms?.utm_source   || null,
      utm_medium:   utms?.utm_medium   || null,
      utm_campaign: utms?.utm_campaign || null,
      utm_content:  utms?.utm_content  || null,
      utm_term:     utms?.utm_term     || null,
      src:          utms?.src          || null,
      sck:          utms?.sck          || null,
    },
    commission: {
      totalPriceInCents:     Math.round(valor * 100),
      gatewayFeeInCents:     0,
      userCommissionInCents: Math.round(valor * 100),
    },
  };

  try {
    const r = await fetch("https://api.utmify.com.br/api-credentials/orders", {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-api-token": token },
      body: JSON.stringify(body),
    });
    if (r.ok) console.log(`📊 UTMify OK | orderId: ${body.orderId}`);
    else console.error(`❌ UTMify erro ${r.status}`);
  } catch(e) { console.error("❌ UTMify fetch erro:", e.message); }
}

// ─── n8n — entrega principal ──────────────────────────────────────────────────
// Envia todos os dados de pagamento + respostas completas do quiz para o n8n,
// que é responsável por gerar e entregar o dorama personalizado.
async function dispararN8N({ email, nome, telefone, valor, itens, utms, pagamentoId, quizAnswers, plano }) {
  const url = process.env.N8N_WEBHOOK_URL;
  if (!url) return;
  try {
    await fetch(url, {
      method:  "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        // Dados do pagamento
        pagamento_id: pagamentoId,
        email,
        nome,
        telefone:     telefone || null,
        total:        valor,
        itens,
        utms:         utms || {},
        // Plano escolhido
        plano: {
          id:      plano?.id      || "",
          nome:    plano?.nome    || "",
          paginas: plano?.paginas || "",
          preco:   plano?.preco   || 0,
        },
        // Respostas do quiz — tudo que é necessário para gerar o dorama
        quiz: quizAnswers || {},
      }),
    });
    console.log(`🔗 n8n disparado | email: ${email} | plano: ${plano?.id}`);
  } catch(e) { console.error("❌ n8n fetch erro:", e.message); }
}

// ─── n8n Recovery (abandono) ──────────────────────────────────────────────────
async function dispararRecovery({ status, email, nome, telefone, pagamentoId, valor = 0, pixCode = "" }) {
  const url = process.env.N8N_RECOVERY_WEBHOOK_URL;
  if (!url) return;

  const tel = (typeof telefone === "string" ? telefone.trim() : telefone) || null;
  if (!tel) return;

  const MAX_TENTATIVAS = 3;
  for (let tentativa = 1; tentativa <= MAX_TENTATIVAS; tentativa++) {
    try {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), 10_000);
      const r = await fetch(url, {
        method:  "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status, email, nome, telefone: tel, pagamento_id: pagamentoId, valor, pix_code: pixCode }),
        signal: controller.signal,
      });
      clearTimeout(timer);
      if (r.ok) {
        console.log(`🔔 Recovery n8n | status: ${status} | tel: ${tel}`);
        return;
      }
    } catch(e) {
      if (tentativa === MAX_TENTATIVAS) console.error(`❌ Recovery erro: ${e.message}`);
      else await new Promise(res => setTimeout(res, 1_000 * tentativa));
    }
  }
}

// ─── Disparo central ao aprovar ───────────────────────────────────────────────
async function aoAprovar({ pagamentoId, email, nome, telefone, valor, itens, utms, eventId, quizAnswers, plano }) {
  console.log(`\n✅ PAGAMENTO APROVADO`);
  console.log(`   ID:    ${pagamentoId}`);
  console.log(`   Email: ${email}`);
  console.log(`   Valor: R$ ${valor}`);
  console.log(`   Plano: ${plano?.id || "?"}`);

  await Promise.allSettled([
    dispararCAPI({ email, nome, valor, eventId: eventId || `purchase_${pagamentoId}` }),
    dispararUTMify({ pagamentoId, email, nomeCliente: nome, telefone, valor, itens, utms }),
    dispararN8N({ email, nome, telefone, valor, itens, utms, pagamentoId, quizAnswers, plano }),
    dispararRecovery({ status: "paid", email, nome, telefone, pagamentoId, valor }),
  ]);
}

// ─── Abacate Pay: cria QR Code PIX ───────────────────────────────────────────
// amount em centavos (inteiro), expiresIn em segundos
async function criarPix({ amountReais, description, nome, email, telefone, externalRef }) {
  const body = {
    amount:      Math.round(amountReais * 100), // centavos
    description: description.slice(0, 255),
    expiresIn:   1800, // 30 minutos
    customer: {
      name:      nome,
      email:     email,
      cellphone: telefone || "",
    },
  };

  const r    = await fetch(`${ABACATE_API}/pixQrCode/create`, {
    method:  "POST",
    headers: abacateHeaders(),
    body:    JSON.stringify(body),
  });
  const data = await r.json();
  if (!r.ok || data.error) throw new Error(data.error || JSON.stringify(data));

  const qr = data.data;
  if (!qr?.brCode) throw new Error("Abacate Pay não retornou brCode");

  return {
    id:             String(qr.id),
    pix_code:       qr.brCode,
    qr_code_base64: (qr.brCodeBase64 || "").replace("data:image/png;base64,", ""),
    status:         qr.status || "PENDING",
  };
}

// status retornado: PENDING | EXPIRED | CANCELLED | PAID | REFUNDED
async function checkPix(id) {
  const r    = await fetch(`${ABACATE_API}/pixQrCode/check?id=${encodeURIComponent(id)}`, {
    headers: abacateHeaders(),
  });
  const data = await r.json();
  return (data.data?.status || data.status || "PENDING").toUpperCase();
}

// ─── Estado em memória ────────────────────────────────────────────────────────
const transacoesProcessadas = new Set();
const transacaoMeta         = new Map();

// ─── GET /health ──────────────────────────────────────────────────────────────
app.get("/health", (req, res) => res.send("OK"));

// ─── GET /config ──────────────────────────────────────────────────────────────
app.get("/config", (req, res) => {
  res.json({
    planos:  PLANOS,
    pixelId: process.env.META_PIXEL_ID || "",
  });
});

// ─── POST /criar-pix ──────────────────────────────────────────────────────────
// Body esperado: { email, telefone, nome, planoId, quizAnswers, utms, eventId }
app.post("/criar-pix", async (req, res) => {
  const { email, telefone, nome: nomeReq, planoId, quizAnswers, utms, eventId } = req.body;
  if (!email)   return res.status(400).json({ erro: "E-mail obrigatório" });
  if (!planoId) return res.status(400).json({ erro: "Plano não informado" });

  const plano = PLANOS[planoId];
  if (!plano) return res.status(400).json({ erro: `Plano inválido: ${planoId}` });

  const nomeCliente = nomeReq || email.split("@")[0];
  const itens       = [{ id: planoId, titulo: plano.nome, preco: plano.preco }];
  const txId        = gerarTxId();

  try {
    const pix = await criarPix({
      amountReais: plano.preco,
      description: plano.nome,
      nome:        nomeCliente,
      email,
      telefone:    telefone || "",
      externalRef: txId,
    });

    transacaoMeta.set(pix.id, {
      email,
      telefone:    telefone || "",
      nome:        nomeCliente,
      valor:       plano.preco,
      eventId:     eventId || "",
      utms:        utms || {},
      itens,
      quizAnswers: quizAnswers || {},
      plano:       { id: planoId, ...plano },
    });

    dispararRecovery({
      status:      "pending",
      email,
      nome:        nomeCliente,
      telefone:    telefone || null,
      pagamentoId: pix.id,
      valor:       plano.preco,
      pixCode:     pix.pix_code,
    }).catch(e => console.error("❌ Recovery (pending):", e.message));

    return res.json({
      id:             pix.id,
      status:         "pending",
      qr_code:        pix.pix_code,
      qr_code_base64: pix.qr_code_base64,
      total:          plano.preco,
      plano:          { id: planoId, ...plano },
    });
  } catch(err) {
    console.error("❌ Criar PIX erro:", err.message);
    return res.status(500).json({ erro: "Erro ao criar PIX", detalhe: err.message });
  }
});

// ─── GET /status/:id ──────────────────────────────────────────────────────────
app.get("/status/:id", async (req, res) => {
  try {
    const id         = req.params.id;
    const abacateStatus = await checkPix(id);
    const status     = abacateStatus === "PAID" ? "approved" : "pending";

    if (status === "approved" && !transacoesProcessadas.has(id)) {
      transacoesProcessadas.add(id);
      const meta = transacaoMeta.get(id);
      if (meta) {
        setImmediate(() => aoAprovar({
          pagamentoId:  id,
          email:        meta.email,
          nome:         meta.nome,
          telefone:     meta.telefone || null,
          valor:        meta.valor,
          itens:        meta.itens,
          utms:         meta.utms,
          eventId:      meta.eventId ? `purchase_${meta.eventId}` : `purchase_${id}`,
          quizAnswers:  meta.quizAnswers,
          plano:        meta.plano,
        }).catch(e => console.error("❌ aoAprovar polling:", e.message)));
        transacaoMeta.delete(id);
      } else {
        console.warn(`⚠️  Polling: meta não encontrada para ${id} — aguarda webhook Abacate Pay`);
      }
    }

    return res.json({ status });
  } catch(err) {
    console.error("❌ Status erro:", err.message);
    return res.status(500).json({ erro: "Erro ao consultar status" });
  }
});

// ─── POST /webhook ────────────────────────────────────────────────────────────
// Abacate Pay envia: { id, event, apiVersion, devMode, data: { ... } }
// Autenticação: query param ?webhookSecret=SEU_SECRET
app.post("/webhook", async (req, res) => {
  res.sendStatus(200); // responde rápido — Abacate Pay tem timeout curto

  try {
    // Valida webhookSecret (se configurado)
    const secret = process.env.ABACATEPAY_WEBHOOK_SECRET;
    if (secret && req.query.webhookSecret !== secret) {
      console.warn("⚠️  Webhook: webhookSecret inválido — ignorado");
      return;
    }

    const body  = Buffer.isBuffer(req.body) ? JSON.parse(req.body.toString()) : req.body;
    const event = body?.event || "";

    console.log(`📨 Webhook Abacate Pay | event: ${event}`);

    // Só processa evento de pagamento PIX confirmado
    if (event !== "pixQrCode.paid" && event !== "transparent.completed" && event !== "billing.paid") {
      console.log(`ℹ️  Webhook ignorado — event: ${event}`);
      return;
    }

    // O id do QR Code está em data.id ou data.pixQrCode.id dependendo da versão
    const paymentId = String(body?.data?.id || body?.data?.pixQrCode?.id || "");
    if (!paymentId) {
      console.warn("⚠️  Webhook sem ID de pagamento");
      return;
    }

    if (transacoesProcessadas.has(paymentId)) {
      console.log(`ℹ️  Webhook ignorado — ${paymentId} já processado`);
      return;
    }
    transacoesProcessadas.add(paymentId);

    const cache = transacaoMeta.get(paymentId);

    // Fallback: tenta recuperar email do payload do webhook
    const emailFallback = body?.data?.customer?.email || body?.data?.email || "";
    const email       = cache?.email       || emailFallback;
    const nome        = cache?.nome        || (email ? email.split("@")[0] : "");
    const telefone    = cache?.telefone    || null;
    const valor       = cache?.valor       || ((body?.data?.amount || 0) / 100); // centavos → reais
    const itens       = cache?.itens       || [{ id: "main", titulo: "Meu Dorama", preco: valor }];
    const utms        = cache?.utms        || {};
    const quizAnswers = cache?.quizAnswers || {};
    const plano       = cache?.plano       || {};
    const rawEventId  = cache?.eventId     || "";
    const eventId     = rawEventId ? `purchase_${rawEventId}` : `purchase_${paymentId}`;

    if (!email) {
      console.error(`❌ Webhook: email não encontrado para ${paymentId}`);
      return;
    }

    await aoAprovar({ pagamentoId: paymentId, email, nome, telefone, valor, itens, utms, eventId, quizAnswers, plano });
    transacaoMeta.delete(paymentId);

  } catch(err) {
    console.error("❌ Webhook erro:", err.message);
  }
});

// ─── Rota explícita para o checkout ──────────────────────────────────────────
app.get("/pagar", (req, res) => {
  res.sendFile(path.join(__dirname, "public/pagar.html"));
});

// ─── SPA fallback — qualquer outra rota serve o quiz ─────────────────────────
app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "public/index.html"));
});

// ─── Start ────────────────────────────────────────────────────────────────────
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`\n🌸 Meu Dorama — Checkout`);
  console.log(`   URL:        http://localhost:${PORT}`);
  console.log(`   Quiz:       http://localhost:${PORT}/`);
  console.log(`   Checkout:   http://localhost:${PORT}/pagar`);
  console.log(`   Abacate Pay: ${process.env.ABACATEPAY_API_KEY      ? "✅" : "⚠️  pendente"}`);
  console.log(`   n8n:         ${process.env.N8N_WEBHOOK_URL         ? "✅" : "⚠️  pendente"}`);
  console.log(`   Meta Pixel:  ${process.env.META_PIXEL_ID           ? "✅" : "não configurado"}`);
  console.log(`   UTMify:      ${process.env.UTMIFY_TOKEN            ? "✅" : "não configurado"}\n`);
});
